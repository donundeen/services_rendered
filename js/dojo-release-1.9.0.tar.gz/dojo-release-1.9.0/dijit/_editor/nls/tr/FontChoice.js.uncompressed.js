define(
"dijit/_editor/nls/tr/FontChoice", ({
	fontSize: "Boyut",
	fontName: "Yazı Tipi",
	formatBlock: "Biçim",
	serif: "serif",
	"sans-serif": "sans-serif",
	monospace: "tek aralıklı",
	cursive: "el yazısı",
	fantasy: "fantazi",
	noFormat: "Yok",
	p: "Paragraf",
	h1: "Başlık",
	h2: "Alt Başlık",
	h3: "Alt Alt Başlık",
	pre: "Önceden Biçimlendirilmiş",
	1: "xx-küçük",
	2: "x-küçük",
	3: "küçük",
	4: "orta",
	5: "büyük",
	6: "x-büyük",
	7: "xx-büyük"
})
);
