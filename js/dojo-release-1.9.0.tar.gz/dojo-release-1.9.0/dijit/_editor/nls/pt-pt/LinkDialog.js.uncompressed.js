define(
"dijit/_editor/nls/pt-pt/LinkDialog", ({
	createLinkTitle: "Propriedades da ligação",
	insertImageTitle: "Propriedades da imagem",
	url: "URL:",
	text: "Descrição:",
	target: "Destino:",
	set: "Definir",
	currentWindow: "Janela actual",
	parentWindow: "Janela ascendente",
	topWindow: "Janela superior",
	newWindow: "Nova janela"
})
);
