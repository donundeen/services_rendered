//>>built
define("dijit/form/nls/ko/ComboBox",({previousMessage:"이전 선택사항",nextMessage:"기타 선택사항"}));
